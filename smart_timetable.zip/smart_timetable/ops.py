"""Timetable edit operations (move / swap / room change / cancel / exam) + alert dispatch."""
from datetime import datetime

import db
import notifier


def simulate_move(df, entry_id, day, slot, room_id=None):
    """Move one session in a COPY of the timetable. If the target slot in the same class is
    occupied, the two sessions swap places. Returns (new_df, swapped_entry_id | None)."""
    new = df.copy()
    row = new[new.id == entry_id].iloc[0]
    other = new[(new.class_id == row.class_id) & (new.day == day) & (new.slot == slot) & (new.id != entry_id)]
    swapped = None
    if not other.empty:
        swapped = int(other.iloc[0].id)
        new.loc[new.id == swapped, "day"] = row.day
        new.loc[new.id == swapped, "slot"] = int(row.slot)
    new.loc[new.id == entry_id, "day"] = day
    new.loc[new.id == entry_id, "slot"] = int(slot)
    if room_id is not None:
        new.loc[new.id == entry_id, "room_id"] = int(room_id)
    return new, swapped


def _log_change(change_type, details, class_id):
    db.execute("INSERT INTO changes(ts, change_type, details, class_id) VALUES(?,?,?,?)",
               (datetime.now().strftime("%Y-%m-%d %H:%M:%S"), change_type, details, int(class_id)))


def _alert(change_type, details, class_id, teacher_ids):
    cname = db.query("SELECT name FROM classes WHERE id=?", (int(class_id),))
    cname = cname.name[0] if len(cname) else "?"
    subject = f"{change_type} - {cname}"
    notifier.notify("class", class_id, subject, details, channels=("app", "email"))
    for tid in sorted({int(t) for t in teacher_ids}):
        notifier.notify("teacher", tid, subject, details, channels=("app", "email", "sms"))


def apply_move(new_df, moved_ids, change_type, details, class_id, notify=True):
    """Persist moved sessions, log the change and alert affected teachers + students."""
    with db.conn() as c:
        for i in moved_ids:
            r = new_df[new_df.id == i].iloc[0]
            c.execute("UPDATE timetable SET day=?, slot=?, room_id=? WHERE id=?",
                      (r.day, int(r.slot), int(r.room_id), int(i)))
    _log_change(change_type, details, class_id)
    if notify:
        _alert(change_type, details, class_id, new_df[new_df.id.isin(moved_ids)].teacher_id)


def cancel_entry(entry_id, details, notify=True):
    row = db.query("SELECT * FROM timetable WHERE id=?", (int(entry_id),)).iloc[0]
    db.execute("DELETE FROM timetable WHERE id=?", (int(entry_id),))
    _log_change("Cancellation", details, row.class_id)
    if notify:
        _alert("Cancellation", details, row.class_id, [row.teacher_id])


def post_exam_change(class_id, details, notify=True):
    _log_change("Exam reschedule", details, class_id)
    if notify:
        tids = db.query("SELECT DISTINCT teacher_id FROM timetable WHERE class_id=?", (int(class_id),)).teacher_id
        _alert("Exam reschedule", details, class_id, tids)
