"""Notifications: in-app (DB), email (SMTP) and SMS (mock, Twilio example included)."""
import os
import smtplib
from datetime import datetime
from email.message import EmailMessage

import db

try:  # optional: load .env if python-dotenv is installed
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:  # pragma: no cover
    pass


def _now():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def _recipient(rtype, rid):
    """Return (display name, email, phone) for a teacher or a class group."""
    if rtype == "teacher":
        df = db.query("SELECT name, email, phone FROM teachers WHERE id=?", (int(rid),))
    else:
        df = db.query("SELECT name, email, '' AS phone FROM classes WHERE id=?", (int(rid),))
    if df.empty:
        return "?", "", ""
    r = df.iloc[0]
    return r["name"], r["email"] or "", r["phone"] or ""


def send_email(to, subject, body):
    """Send via SMTP. Returns a status string; never raises."""
    host = os.environ.get("SMTP_HOST")
    if not host:
        return "skipped (SMTP not configured)"
    try:
        msg = EmailMessage()
        msg["From"] = os.environ.get("SMTP_FROM", os.environ.get("SMTP_USER", ""))
        msg["To"], msg["Subject"] = to, subject
        msg.set_content(body)
        with smtplib.SMTP(host, int(os.environ.get("SMTP_PORT", 587)), timeout=10) as s:
            s.starttls()
            s.login(os.environ["SMTP_USER"], os.environ["SMTP_PASSWORD"])
            s.send_message(msg)
        return "sent"
    except Exception as e:  # noqa: BLE001 - we want to report any failure, not crash the app
        return f"failed: {e}"


def send_sms_mock(phone, body):
    """Mock SMS: prints to the console. Replace with Twilio for real SMS:

        from twilio.rest import Client
        Client(SID, TOKEN).messages.create(to=phone, from_=TWILIO_NUMBER, body=body)
    """
    print(f"[MOCK SMS to {phone}] {body}")
    return "mock-sent"


def notify(rtype, rid, subject, message, channels=("app", "email", "sms")):
    """Notify a teacher or a class (students). Logs every channel in `notifications`."""
    name, email, phone = _recipient(rtype, rid)
    ts = _now()
    sql = ("INSERT INTO notifications(ts, recipient_type, recipient_id, channel, subject, message, status, is_read) "
           "VALUES(?,?,?,?,?,?,?,?)")
    if "app" in channels:
        db.execute(sql, (ts, rtype, int(rid), "app", subject, message, "delivered", 0))
    if "email" in channels and email:
        db.execute(sql, (ts, rtype, int(rid), "email", subject, message, send_email(email, subject, message), 1))
    if "sms" in channels and phone:
        db.execute(sql, (ts, rtype, int(rid), "sms", subject, message, send_sms_mock(phone, f"{subject}: {message}"), 1))


def unread(rtype, rid):
    return db.query("SELECT * FROM notifications WHERE recipient_type=? AND recipient_id=? AND channel='app' "
                    "AND is_read=0 ORDER BY id DESC", (rtype, int(rid)))


def inbox(rtype, rid, limit=50):
    return db.query("SELECT * FROM notifications WHERE recipient_type=? AND recipient_id=? AND channel='app' "
                    "ORDER BY id DESC LIMIT ?", (rtype, int(rid), limit))


def mark_all_read(rtype, rid):
    db.execute("UPDATE notifications SET is_read=1 WHERE recipient_type=? AND recipient_id=? AND channel='app'",
               (rtype, int(rid)))
