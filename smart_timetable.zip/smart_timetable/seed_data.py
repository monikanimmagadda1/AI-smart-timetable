"""Sample data so the demo works immediately. Run `python seed_data.py --force` to reset."""
import sys

import db

TEACHERS = [  # name, email, phone, subjects, unavailable
    ("Mr. Rao", "rao@example.com", "+911000000001", "Maths", ""),
    ("Ms. Iyer", "iyer@example.com", "+911000000002", "English", ""),
    ("Dr. Khan", "khan@example.com", "+911000000003", "Science", ""),
    ("Ms. Das", "das@example.com", "+911000000004", "History, Geography", "Fri-5, Fri-6"),
    ("Mr. Reddy", "reddy@example.com", "+911000000005", "Computer", ""),
    ("Mr. Singh", "singh@example.com", "+911000000006", "PE", "Mon-1"),
]
CLASSES = [("10-A", 30, "class10a@example.com"), ("10-B", 28, "class10b@example.com"),
           ("10-C", 32, "class10c@example.com")]
ROOMS = [("R101", 35), ("R102", 35), ("R103", 30), ("Lab-1", 40)]
SUBJECTS = [("Maths", 5, "Mr. Rao"), ("English", 4, "Ms. Iyer"), ("Science", 5, "Dr. Khan"),
            ("History", 3, "Ms. Das"), ("Geography", 3, "Ms. Das"), ("Computer", 3, "Mr. Reddy"),
            ("PE", 2, "Mr. Singh")]


def seed(force=False):
    db.init_db()
    with db.conn() as c:
        if not force and c.execute("SELECT COUNT(*) FROM teachers").fetchone()[0] > 0:
            return False
        for t in ("teachers", "classes", "rooms", "subjects", "timetable", "changes",
                  "notifications", "prefs", "reminder_log"):
            c.execute(f"DELETE FROM {t}")
            c.execute("DELETE FROM sqlite_sequence WHERE name=?", (t,))
        tid = {n: c.execute("INSERT INTO teachers(name,email,phone,subjects,unavailable) VALUES(?,?,?,?,?)",
                            (n, e, p, s, u)).lastrowid for n, e, p, s, u in TEACHERS}
        cid = {n: c.execute("INSERT INTO classes(name,size,email) VALUES(?,?,?)", (n, z, e)).lastrowid
               for n, z, e in CLASSES}
        c.executemany("INSERT INTO rooms(name,capacity) VALUES(?,?)", ROOMS)
        for cls in cid.values():
            for name, hours, teacher in SUBJECTS:
                c.execute("INSERT INTO subjects(name,class_id,teacher_id,hours) VALUES(?,?,?,?)",
                          (name, cls, tid[teacher], hours))
    return True


if __name__ == "__main__":
    print("Seeded." if seed(force="--force" in sys.argv) else "Data already exists (use --force to reset).")
