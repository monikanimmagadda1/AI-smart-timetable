"""Class reminders: a background job checks every minute and sends each reminder once."""
from datetime import datetime, time

import db
import notifier
import utils

WEEKDAYS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
DEFAULT_LEAD = 15


def get_lead(rtype, rid):
    df = db.query("SELECT lead_minutes FROM prefs WHERE recipient_type=? AND recipient_id=?", (rtype, int(rid)))
    return int(df.lead_minutes[0]) if len(df) else DEFAULT_LEAD


def set_lead(rtype, rid, minutes):
    db.execute("INSERT OR REPLACE INTO prefs(recipient_type, recipient_id, lead_minutes) VALUES(?,?,?)",
               (rtype, int(rid), int(minutes)))


def _start(now, slot):
    times = utils.get_slot_times()
    if slot - 1 >= len(times):
        return None
    return datetime.combine(now.date(), time.fromisoformat(times[slot - 1]))


def _text(e):
    return f"{e.subject} with {e.teacher_name} in {e.room_name} for {e.class_name}, starting at {utils.slot_label(int(e.slot)).split(' · ')[1].split('–')[0]}."


def check_reminders(now=None):
    """Send reminders for sessions starting within each recipient's lead time.
    A (session, date, recipient) is only ever reminded once. Returns number sent."""
    now = now or datetime.now()
    df = db.timetable_full()
    df = df[df.day == WEEKDAYS[now.weekday()]]
    sent = 0
    for e in df.itertuples():
        start = _start(now, int(e.slot))
        if start is None:
            continue
        mins = (start - now).total_seconds() / 60
        if mins < 0:
            continue
        for rtype, rid in (("teacher", e.teacher_id), ("class", e.class_id)):
            if mins > get_lead(rtype, rid):
                continue
            done = db.query("SELECT 1 FROM reminder_log WHERE entry_id=? AND date=? AND recipient_type=? AND recipient_id=?",
                            (int(e.id), str(now.date()), rtype, int(rid)))
            if len(done):
                continue
            db.execute("INSERT INTO reminder_log VALUES(?,?,?,?)", (int(e.id), str(now.date()), rtype, int(rid)))
            notifier.notify(rtype, rid, f"Reminder: class in {int(round(mins))} min", _text(e),
                            channels=("app", "email"))
            sent += 1
    return sent


def send_test_reminder(rtype, rid):
    """Demo helper: send a reminder for the recipient's first session right now."""
    df = db.timetable_full()
    df = df[(df.teacher_id if rtype == "teacher" else df.class_id) == int(rid)]
    if df.empty:
        return "No sessions found - generate a timetable first."
    e = df.iloc[0]
    notifier.notify(rtype, rid, "[TEST] Class reminder", _text(e), channels=("app", "email"))
    return "Test reminder sent - check your notifications."


def start_scheduler():
    """Start the APScheduler background job (call once, e.g. via st.cache_resource)."""
    from apscheduler.schedulers.background import BackgroundScheduler
    sched = BackgroundScheduler()
    sched.add_job(check_reminders, "interval", minutes=1, id="reminders",
                  replace_existing=True, max_instances=1, coalesce=True)
    sched.start()
    return sched
