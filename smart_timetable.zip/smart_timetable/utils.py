"""Shared helpers: settings parsing, colours, HTML timetable grid, conflict checking."""
import html
import zlib

import db

PALETTE = ["#ffd6d6", "#d6e8ff", "#d9f5d0", "#fff1c2", "#e8d9ff", "#ffe0c2",
           "#c9f2ee", "#f8d4ec", "#e2ecc9", "#d4dcf8", "#f5e0d0", "#d0f0f8"]


def get_days():
    return [d.strip() for d in db.get_setting("days").split(",") if d.strip()]


def get_slot_times():
    return [t.strip() for t in db.get_setting("slot_times").split(",") if t.strip()]


def slot_label(slot):
    times = get_slot_times()
    minutes = int(db.get_setting("slot_minutes") or 50)
    if slot - 1 >= len(times):
        return f"P{slot}"
    h, m = map(int, times[slot - 1].split(":"))
    end = h * 60 + m + minutes
    return f"P{slot} · {times[slot-1]}–{end // 60:02d}:{end % 60:02d}"


def parse_unavailable(text):
    """'Mon-1, Fri-5, Tue' -> {('Mon',1), ('Fri',5), ('Tue',1..n)}. Bare day = whole day."""
    out = set()
    n = len(get_slot_times())
    for tok in (text or "").split(","):
        tok = tok.strip()
        if not tok:
            continue
        if "-" in tok:
            d, s = tok.split("-", 1)
            if s.strip().isdigit():
                out.add((d.strip(), int(s)))
        else:
            out.update((tok, s) for s in range(1, n + 1))
    return out


def subject_color(subject):
    return PALETTE[zlib.crc32(str(subject).encode()) % len(PALETTE)]


def render_grid(df, mode="class", highlight_ids=()):
    """Return an HTML timetable (days = columns, periods = rows).

    df must already be filtered to ONE class / teacher / room.
    mode decides which extra details are shown in each cell.
    """
    days, n = get_days(), len(get_slot_times())
    cell_map = {}
    for _, r in df.iterrows():
        cell_map.setdefault((r.day, int(r.slot)), []).append(r)
    css = ("<style>.tt{width:100%;border-collapse:collapse;table-layout:fixed}"
           ".tt th{background:#eef1f6;color:#111;padding:8px;border:1px solid #cfd6e0}"
           ".tt td{border:1px solid #cfd6e0;padding:6px;height:64px;vertical-align:top;"
           "font-size:13px;color:#1a1a1a}.tt .pl{background:#f7f8fb;font-weight:600;width:110px}"
           ".tt small{color:#444}</style>")
    rows = ["<table class='tt'><tr><th>Period</th>" + "".join(f"<th>{html.escape(d)}</th>" for d in days) + "</tr>"]
    for s in range(1, n + 1):
        rows.append(f"<tr><td class='pl'>{html.escape(slot_label(s))}</td>")
        for d in days:
            items = cell_map.get((d, s), [])
            if not items:
                rows.append("<td></td>")
                continue
            parts = []
            for r in items:
                if mode == "class":
                    sub = f"{r.teacher_name} · {r.room_name}"
                elif mode == "teacher":
                    sub = f"{r.class_name} · {r.room_name}"
                else:
                    sub = f"{r.class_name} · {r.teacher_name}"
                parts.append(f"<div style='background:{subject_color(r.subject)};border-radius:6px;padding:4px;"
                             + ("outline:3px solid #ff4b4b;" if int(r.id) in highlight_ids else "")
                             + f"'><b>{html.escape(str(r.subject))}</b><br><small>{html.escape(sub)}</small></div>")
            border = "border:2px solid #d00;" if len(items) > 1 else ""
            rows.append(f"<td style='{border}'>{''.join(parts)}</td>")
        rows.append("</tr>")
    rows.append("</table>")
    return css + "".join(rows)


def find_conflicts(df):
    """Return a list of human-readable clashes in a timetable DataFrame."""
    teachers = db.query("SELECT id, name, unavailable FROM teachers").set_index("id")
    rooms = db.query("SELECT id, name, capacity FROM rooms").set_index("id")
    classes = db.query("SELECT id, name, size FROM classes").set_index("id")
    msgs = []
    for (d, s), g in df.groupby(["day", "slot"]):
        for col, label, names in (("teacher_id", "Teacher", teachers.name),
                                  ("room_id", "Room", rooms.name),
                                  ("class_id", "Class", classes.name)):
            dup = g[g.duplicated(col, keep=False)]
            for key in dup[col].dropna().unique():
                msgs.append(f"{label} {names.get(key, key)} is double-booked on {d}, period {int(s)}")
    for _, r in df.iterrows():
        if r.teacher_id in teachers.index and (r.day, int(r.slot)) in parse_unavailable(teachers.unavailable[r.teacher_id]):
            msgs.append(f"Teacher {teachers.name[r.teacher_id]} is unavailable on {r.day}, period {int(r.slot)}")
        if r.room_id in rooms.index and r.class_id in classes.index and rooms.capacity[r.room_id] < classes["size"][r.class_id]:
            msgs.append(f"Room {rooms.name[r.room_id]} (capacity {rooms.capacity[r.room_id]}) is too small for class {classes.name[r.class_id]} ({classes['size'][r.class_id]})")
    return sorted(set(msgs))
