"""AI Smart Timetable & Alert System - Streamlit entry point.  Run: streamlit run app.py"""
import pandas as pd
import streamlit as st

import db
import notifier
import ops
import reminders
import scheduler_engine
import seed_data
import utils

st.set_page_config(page_title="AI Smart Timetable", page_icon="🗓️", layout="wide")

# ---------- one-time setup ----------
db.init_db()
if db.query("SELECT COUNT(*) AS n FROM teachers").n[0] == 0:
    seed_data.seed()  # demo data on first run


@st.cache_resource
def _start_background_jobs():
    return reminders.start_scheduler()


try:
    _start_background_jobs()
except Exception as e:  # noqa: BLE001
    st.sidebar.warning(f"Reminder scheduler not running: {e}")

DAYS = utils.get_days()
N_SLOTS = len(utils.get_slot_times())

# ---------- sidebar: role switch ----------
st.sidebar.title("🗓️ Smart Timetable")
role = st.sidebar.radio("Role", ["Admin", "Teacher", "Student"], horizontal=True)
me = None  # (recipient_type, recipient_id)
if role == "Teacher":
    tdf = db.query("SELECT id, name FROM teachers ORDER BY name")
    if tdf.empty:
        st.sidebar.warning("No teachers yet - switch to Admin.")
    else:
        tid = st.sidebar.selectbox("I am", tdf.id, format_func=lambda i: tdf.set_index("id").name[i])
        me = ("teacher", int(tid))
elif role == "Student":
    cdf = db.query("SELECT id, name FROM classes ORDER BY name")
    if cdf.empty:
        st.sidebar.warning("No classes yet - switch to Admin.")
    else:
        cid_ = st.sidebar.selectbox("My class", cdf.id, format_func=lambda i: cdf.set_index("id").name[i])
        me = ("class", int(cid_))

if "toasted" not in st.session_state:
    st.session_state.toasted = set()


@st.fragment(run_every=15)
def notification_badge(rtype, rid):
    """Polls every 15 s: shows the unread count and pops a toast for each new alert."""
    df = notifier.unread(rtype, rid)
    for r in df.itertuples():
        if r.id not in st.session_state.toasted:
            st.session_state.toasted.add(r.id)
            st.toast(f"**{r.subject}**\n\n{r.message}", icon="🔔")
    st.metric("🔔 Unread alerts", len(df))


if me:
    with st.sidebar:
        notification_badge(*me)

PAGES = (["📊 Overview", "🗂️ Data", "⚙️ Generate", "📅 Timetable", "📣 Post Change", "📨 Delivery Log"]
         if role == "Admin" else ["📅 My Timetable", "🔔 Notifications", "⏰ Reminders"])
page = st.sidebar.radio("Go to", PAGES)


# ---------- helpers ----------
def crud(table, cols, key, config=None):
    """Editable table (add / edit / delete rows) with a Save button."""
    df = db.query(f"SELECT id, {', '.join(c for c, _ in cols)} FROM {table} ORDER BY id")
    edited = st.data_editor(df, num_rows="dynamic", hide_index=True, disabled=["id"],
                            column_config=config, key=f"ed_{key}")
    if st.button("💾 Save changes", key=f"save_{key}"):
        db.save_table(table, edited, cols)
        st.success("Saved.")
        st.rerun()


def entry_label(r):
    return f"{r.day} P{int(r.slot)} · {r.subject} ({r.teacher_name}, {r.room_name})"


def edit_panel(mode, key, class_id=None):
    """Move / swap a session or change its room, with instant conflict preview.
    mode: 'edit' (day+period+room), 'time' (day+period), 'room' (room only)."""
    df = db.timetable_full()
    if df.empty:
        st.info("Generate a timetable first.")
        return
    classes = db.query("SELECT id, name FROM classes ORDER BY name").set_index("id").name
    rooms = db.query("SELECT id, name FROM rooms ORDER BY name").set_index("id").name
    cid = st.selectbox("Class", list(classes.index), format_func=classes.get, key=f"{key}_cls")
    entries = df[df.class_id == cid]
    labels = {int(r.id): entry_label(r) for r in entries.itertuples()}
    if not labels:
        st.info("This class has no sessions.")
        return
    eid = st.selectbox("Session", list(labels), format_func=labels.get, key=f"{key}_e")
    cur = entries[entries.id == eid].iloc[0]
    c1, c2, c3 = st.columns(3)
    day, slot, room = cur.day, int(cur.slot), int(cur.room_id)
    if mode in ("edit", "time"):
        day = c1.selectbox("New day", DAYS, index=DAYS.index(cur.day) if cur.day in DAYS else 0, key=f"{key}_d{eid}")
        slot = c2.selectbox("New period", list(range(1, N_SLOTS + 1)), index=int(cur.slot) - 1, key=f"{key}_s{eid}")
    if mode in ("edit", "room"):
        opts = list(rooms.index)
        room = c3.selectbox("Room", opts, index=opts.index(int(cur.room_id)) if int(cur.room_id) in opts else 0,
                            format_func=rooms.get, key=f"{key}_r{eid}")

    new_df, swapped = ops.simulate_move(df, eid, day, slot, room)
    moved = {eid} | ({swapped} if swapped else set())
    unchanged = (day, slot, room) == (cur.day, int(cur.slot), int(cur.room_id))
    conflicts = [c for c in utils.find_conflicts(new_df) if c not in set(utils.find_conflicts(df))]

    st.markdown("**Preview** (changed sessions outlined in red)")
    st.markdown(utils.render_grid(new_df[new_df.class_id == cid], "class", moved), unsafe_allow_html=True)
    if swapped:
        other = entries[entries.id == swapped].iloc[0]
        st.info(f"That period is taken by **{other.subject}**, so the two sessions will swap.")
    if conflicts:
        st.error("Cannot save - this causes conflicts:\n\n" + "\n".join(f"- {c}" for c in conflicts))
    elif not unchanged:
        st.success("No conflicts - safe to save.")

    kinds = []
    if (day, slot) != (cur.day, int(cur.slot)):
        kinds.append("Time shift")
    if room != int(cur.room_id):
        kinds.append("Room change")
    note = st.text_input("Optional note for the alert", key=f"{key}_note{eid}")
    notify_on = st.checkbox("Send alerts to affected teachers & students", value=True, key=f"{key}_n{eid}")
    if st.button("✅ Save change", disabled=bool(conflicts) or unchanged, type="primary", key=f"{key}_go"):
        new = new_df[new_df.id == eid].iloc[0]
        details = (f"{cur.subject}: {cur.day} P{int(cur.slot)} in {cur.room_name} → "
                   f"{new.day} P{int(new.slot)} in {rooms.get(int(new.room_id), '?')}."
                   + (f" Note: {note}" if note else ""))
        ops.apply_move(new_df, moved, " & ".join(kinds), details, cid, notify_on)
        st.success("Timetable updated" + (" and alerts sent." if notify_on else "."))
        st.rerun()


# =====================  ADMIN PAGES  =====================
if role == "Admin" and page == "📊 Overview":
    st.title("📊 Overview")
    counts = {t: int(db.query(f"SELECT COUNT(*) AS n FROM {t}").n[0])
              for t in ("teachers", "classes", "rooms", "subjects", "timetable")}
    cols = st.columns(5)
    for col, (k, v) in zip(cols, counts.items()):
        col.metric(k.capitalize() if k != "timetable" else "Sessions", v)
    st.subheader("Recent changes")
    ch = db.query("SELECT ts, change_type, details FROM changes ORDER BY id DESC LIMIT 10")
    st.dataframe(ch, hide_index=True) if len(ch) else st.caption("No changes posted yet.")
    st.subheader("Reminders")
    st.caption("A background job checks every minute. Use the buttons below to demo without waiting.")
    a, b = st.columns(2)
    if a.button("Run reminder check now"):
        st.info(f"{reminders.check_reminders()} reminder(s) sent for sessions starting soon.")
    tdf = db.query("SELECT id, name FROM teachers ORDER BY name")
    if len(tdf):
        who = b.selectbox("Test reminder for teacher", tdf.id, format_func=lambda i: tdf.set_index("id").name[i])
        if b.button("Send test reminder"):
            st.info(reminders.send_test_reminder("teacher", int(who)))
    with st.expander("⚠️ Reset demo data"):
        if st.checkbox("I understand this deletes everything and reloads sample data") and st.button("Reset"):
            seed_data.seed(force=True)
            st.rerun()

elif role == "Admin" and page == "🗂️ Data":
    st.title("🗂️ Master data")
    t1, t2, t3, t4, t5 = st.tabs(["Teachers", "Classes", "Rooms", "Subjects", "Settings"])
    with t1:
        st.caption("Unavailable: comma list like `Mon-1, Fri-5` (day-period). A bare day (`Wed`) blocks the whole day.")
        crud("teachers", [("name", "t"), ("email", "t"), ("phone", "t"), ("subjects", "t"), ("unavailable", "t")], "t")
    with t2:
        crud("classes", [("name", "t"), ("size", "i"), ("email", "t")], "c",
             {"size": st.column_config.NumberColumn("size", min_value=1, step=1)})
    with t3:
        crud("rooms", [("name", "t"), ("capacity", "i")], "r",
             {"capacity": st.column_config.NumberColumn("capacity", min_value=1, step=1)})
    with t4:
        st.caption("Hours = periods per week for that class. Class and teacher names must be unique.")
        cl, te = db.query("SELECT id, name FROM classes"), db.query("SELECT id, name FROM teachers")
        cmap, tmap = dict(zip(cl.name, cl.id)), dict(zip(te.name, te.id))
        sub = db.query("""SELECT s.id, s.name AS subject, c.name AS class, t.name AS teacher, s.hours
                          FROM subjects s LEFT JOIN classes c ON c.id=s.class_id
                          LEFT JOIN teachers t ON t.id=s.teacher_id ORDER BY s.class_id, s.id""")
        ed = st.data_editor(sub, num_rows="dynamic", hide_index=True, disabled=["id"], key="ed_sub", column_config={
            "class": st.column_config.SelectboxColumn("class", options=list(cmap)),
            "teacher": st.column_config.SelectboxColumn("teacher", options=list(tmap)),
            "hours": st.column_config.NumberColumn("hours", min_value=1, max_value=40, step=1)})
        if st.button("💾 Save changes", key="save_sub"):
            ed = ed.dropna(subset=["subject", "class", "teacher"]).copy()
            ed["name"], ed["class_id"], ed["teacher_id"] = ed["subject"], ed["class"].map(cmap), ed["teacher"].map(tmap)
            db.save_table("subjects", ed, [("name", "t"), ("class_id", "i"), ("teacher_id", "i"), ("hours", "i")])
            st.success("Saved.")
            st.rerun()
    with t5:
        days = st.text_input("Working days (comma separated)", db.get_setting("days"))
        times = st.text_input("Start time of each period (HH:MM, comma separated - number of items = periods/day)",
                              db.get_setting("slot_times"))
        mins = st.number_input("Period length (minutes)", 10, 180, int(db.get_setting("slot_minutes")))
        if st.button("💾 Save settings"):
            try:
                for t in times.split(","):
                    h, m = t.strip().split(":")
                    assert 0 <= int(h) < 24 and 0 <= int(m) < 60
                db.set_setting("days", days)
                db.set_setting("slot_times", times)
                db.set_setting("slot_minutes", int(mins))
                st.success("Saved. Regenerate the timetable if the number of days/periods changed.")
            except Exception:  # noqa: BLE001
                st.error("Times must look like 09:00, 10:00, ...")

elif role == "Admin" and page == "⚙️ Generate":
    st.title("⚙️ AI timetable generation")
    engine = "OR-Tools CP-SAT" if scheduler_engine.HAVE_ORTOOLS else "greedy fallback (install ortools for optimisation)"
    st.caption(f"Engine: {engine}. Hard rules: no teacher/room/class clashes, room capacity, exact weekly hours, "
               "teacher availability. Soft goals: spread subjects across days, avoid 3 periods in a row.")
    limit = st.slider("Solver time limit (seconds)", 5, 120, 20)
    st.warning("Generating replaces the current timetable (manual edits will be lost).")
    if st.button("🚀 Generate timetable", type="primary"):
        with st.spinner("Solving..."):
            res = scheduler_engine.generate(limit)
        if res["ok"]:
            st.success(f"Timetable generated: {res['rows']} sessions (status: {res['status']}).")
        else:
            st.error(f"Could not generate a timetable (status: {res['status']}).")
        for m in res["messages"]:
            st.write(f"- {m}")

elif role == "Admin" and page == "📅 Timetable":
    st.title("📅 Timetable")
    df = db.timetable_full()
    if df.empty:
        st.info("No timetable yet - go to **Generate**.")
    else:
        view = st.radio("View by", ["Class", "Teacher", "Room"], horizontal=True)
        col, idcol, nm = {"Class": ("class_id", "class_id", "class_name"),
                          "Teacher": ("teacher_id", "teacher_id", "teacher_name"),
                          "Room": ("room_id", "room_id", "room_name")}[view]
        names = df[[idcol, nm]].drop_duplicates().set_index(idcol)[nm].sort_values()
        pick = st.selectbox(view, list(names.index), format_func=names.get)
        st.markdown(utils.render_grid(df[df[col] == pick], view.lower()), unsafe_allow_html=True)
        problems = utils.find_conflicts(df)
        if problems:
            st.error("Conflicts in the current timetable:\n\n" + "\n".join(f"- {p}" for p in problems))
        st.divider()
        st.subheader("✏️ Edit (move / swap sessions)")
        edit_panel("edit", "tt")

elif role == "Admin" and page == "📣 Post Change":
    st.title("📣 Post a change")
    ctype = st.selectbox("Change type", ["Room change", "Time shift", "Cancellation", "Exam reschedule"])
    if ctype == "Room change":
        edit_panel("room", "pc_room")
    elif ctype == "Time shift":
        edit_panel("time", "pc_time")
    elif ctype == "Cancellation":
        df = db.timetable_full()
        classes = db.query("SELECT id, name FROM classes ORDER BY name").set_index("id").name
        if df.empty or classes.empty:
            st.info("Nothing to cancel yet.")
        else:
            cid = st.selectbox("Class", list(classes.index), format_func=classes.get, key="cx_c")
            ent = df[df.class_id == cid]
            labels = {int(r.id): entry_label(r) for r in ent.itertuples()}
            eid = st.selectbox("Session to cancel", list(labels), format_func=labels.get)
            reason = st.text_input("Reason (optional)")
            if st.button("❌ Cancel session & notify", type="primary"):
                row = ent[ent.id == eid].iloc[0]
                ops.cancel_entry(eid, f"{row.subject} on {row.day} P{int(row.slot)} is cancelled."
                                 + (f" Reason: {reason}" if reason else ""))
                st.success("Session removed and alerts sent.")
                st.rerun()
    else:
        classes = db.query("SELECT id, name FROM classes ORDER BY name").set_index("id").name
        if classes.empty:
            st.info("Add a class first.")
        else:
            cid = st.selectbox("Class", list(classes.index), format_func=classes.get)
            exam = st.text_input("Exam name", "Unit Test 2")
            d = st.date_input("New date")
            t = st.time_input("New time")
            note = st.text_input("Note (optional)")
            if st.button("📝 Post exam reschedule & notify", type="primary"):
                ops.post_exam_change(cid, f"{exam} is rescheduled to {d:%d %b %Y} at {t:%H:%M}."
                                     + (f" {note}" if note else ""))
                st.success("Exam change posted and alerts sent.")

elif role == "Admin" and page == "📨 Delivery Log":
    st.title("📨 Delivery log")
    st.caption("Every in-app / email / SMS notification. Email shows 'skipped' until SMTP is configured in .env; SMS is a console mock.")
    log = db.query("""SELECT n.ts, n.channel, n.recipient_type AS type,
                             COALESCE(t.name, c.name, '?') AS recipient, n.subject, n.message, n.status
                      FROM notifications n
                      LEFT JOIN teachers t ON n.recipient_type='teacher' AND t.id = n.recipient_id
                      LEFT JOIN classes c ON n.recipient_type='class' AND c.id = n.recipient_id
                      ORDER BY n.id DESC LIMIT 300""")
    if log.empty:
        st.info("Nothing sent yet.")
    else:
        chan = st.multiselect("Channels", ["app", "email", "sms"], ["app", "email", "sms"])
        st.dataframe(log[log.channel.isin(chan)], hide_index=True)

# =====================  TEACHER / STUDENT PAGES  =====================
elif page == "📅 My Timetable" and me:
    st.title("📅 My timetable")
    df = db.timetable_full()
    rtype, rid = me
    if df.empty:
        st.info("No timetable has been generated yet.")
    elif rtype == "teacher":
        st.markdown(utils.render_grid(df[df.teacher_id == rid], "teacher"), unsafe_allow_html=True)
    else:
        st.markdown(utils.render_grid(df[df.class_id == rid], "class"), unsafe_allow_html=True)

elif page == "🔔 Notifications" and me:
    st.title("🔔 Notifications")
    box = notifier.inbox(*me)
    if st.button("Mark all as read"):
        notifier.mark_all_read(*me)
        st.rerun()
    if box.empty:
        st.info("No notifications yet.")
    for r in box.itertuples():
        with st.container(border=True):
            st.markdown(f"{'🆕 ' if r.is_read == 0 else ''}**{r.subject}**  \n{r.message}")
            st.caption(r.ts)

elif page == "⏰ Reminders" and me:
    st.title("⏰ Class reminders")
    rtype, rid = me
    cur = reminders.get_lead(rtype, rid)
    presets = [10, 15, 30, 45, 60]
    choice = st.selectbox("Remind me before class", presets + ["Custom"],
                          index=presets.index(cur) if cur in presets else len(presets),
                          format_func=lambda v: f"{v} minutes" if v != "Custom" else "Custom...")
    lead = st.number_input("Custom minutes", 1, 240, cur) if choice == "Custom" else choice
    if st.button("💾 Save lead time"):
        reminders.set_lead(rtype, rid, int(lead))
        st.success(f"You will be reminded {int(lead)} minutes before each class.")
    st.divider()
    if st.button("🔔 Test reminder now"):
        st.info(reminders.send_test_reminder(rtype, rid))
        st.rerun()
