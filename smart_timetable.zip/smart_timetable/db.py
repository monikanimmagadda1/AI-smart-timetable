"""SQLite storage layer.

A new short-lived connection is opened for every call, which keeps things
thread-safe (Streamlit reruns + the APScheduler background thread both use it).
"""
import os
import sqlite3

import pandas as pd

DB_PATH = os.environ.get(
    "TIMETABLE_DB", os.path.join(os.path.dirname(os.path.abspath(__file__)), "timetable.db")
)

SCHEMA = """
CREATE TABLE IF NOT EXISTS teachers(
    id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL,
    email TEXT DEFAULT '', phone TEXT DEFAULT '',
    subjects TEXT DEFAULT '', unavailable TEXT DEFAULT '');
CREATE TABLE IF NOT EXISTS classes(
    id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL,
    size INTEGER NOT NULL DEFAULT 30, email TEXT DEFAULT '');
CREATE TABLE IF NOT EXISTS rooms(
    id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL,
    capacity INTEGER NOT NULL DEFAULT 30);
CREATE TABLE IF NOT EXISTS subjects(
    id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL,
    class_id INTEGER, teacher_id INTEGER, hours INTEGER NOT NULL DEFAULT 1);
CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT);
CREATE TABLE IF NOT EXISTS timetable(
    id INTEGER PRIMARY KEY AUTOINCREMENT, class_id INTEGER, day TEXT, slot INTEGER,
    subject TEXT, teacher_id INTEGER, room_id INTEGER);
CREATE TABLE IF NOT EXISTS changes(
    id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT, change_type TEXT,
    details TEXT, class_id INTEGER);
CREATE TABLE IF NOT EXISTS notifications(
    id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT, recipient_type TEXT, recipient_id INTEGER,
    channel TEXT, subject TEXT, message TEXT, status TEXT, is_read INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS prefs(
    recipient_type TEXT, recipient_id INTEGER, lead_minutes INTEGER,
    PRIMARY KEY(recipient_type, recipient_id));
CREATE TABLE IF NOT EXISTS reminder_log(
    entry_id INTEGER, date TEXT, recipient_type TEXT, recipient_id INTEGER,
    PRIMARY KEY(entry_id, date, recipient_type, recipient_id));
"""

DEFAULT_SETTINGS = {
    "days": "Mon,Tue,Wed,Thu,Fri",
    "slot_times": "09:00,10:00,11:00,12:00,14:00,15:00",  # start time of each period
    "slot_minutes": "50",
}


def conn():
    c = sqlite3.connect(DB_PATH, timeout=30)
    c.row_factory = sqlite3.Row
    return c


def init_db():
    """Create tables and default settings if they do not exist."""
    with conn() as c:
        c.executescript(SCHEMA)
        for k, v in DEFAULT_SETTINGS.items():
            c.execute("INSERT OR IGNORE INTO settings(key, value) VALUES(?, ?)", (k, v))


def query(sql, params=()):
    """Run a SELECT and return a DataFrame."""
    c = conn()
    try:
        return pd.read_sql_query(sql, c, params=params)
    finally:
        c.close()


def execute(sql, params=()):
    """Run one write statement; returns lastrowid."""
    with conn() as c:
        return c.execute(sql, params).lastrowid


def get_setting(key):
    df = query("SELECT value FROM settings WHERE key=?", (key,))
    return df.value[0] if len(df) else DEFAULT_SETTINGS.get(key, "")


def set_setting(key, value):
    execute("INSERT OR REPLACE INTO settings(key, value) VALUES(?, ?)", (key, str(value)))


def _py(value, kind):
    """Convert pandas/numpy values to plain Python for sqlite."""
    missing = value is None or (not isinstance(value, str) and pd.isna(value))
    if kind == "i":
        return 0 if missing else int(value)
    return "" if missing else str(value).strip()


def save_table(table, df, cols):
    """Upsert an edited DataFrame (from st.data_editor) into `table`.

    cols = [(column_name, "t" | "i")]. Rows with an existing id are updated, rows
    without an id are inserted, and ids missing from the DataFrame are deleted.
    Rows whose first column is empty are ignored.
    """
    names = [c for c, _ in cols]
    with conn() as c:
        existing = {r[0] for r in c.execute(f"SELECT id FROM {table}")}
        keep = set()
        for _, row in df.iterrows():
            vals = [_py(row[n], k) for n, k in cols]
            if vals[0] in ("", 0):
                continue
            rid = row.get("id")
            if rid is not None and not pd.isna(rid) and int(rid) in existing:
                keep.add(int(rid))
                sets = ", ".join(f"{n}=?" for n in names)
                c.execute(f"UPDATE {table} SET {sets} WHERE id=?", vals + [int(rid)])
            else:
                marks = ",".join("?" * len(names))
                c.execute(f"INSERT INTO {table}({','.join(names)}) VALUES({marks})", vals)
        for rid in existing - keep:
            c.execute(f"DELETE FROM {table} WHERE id=?", (rid,))


def timetable_full():
    """Timetable joined with class / teacher / room names."""
    return query(
        """SELECT t.id, t.class_id, COALESCE(c.name,'?') AS class_name, t.day, t.slot,
                  t.subject, t.teacher_id, COALESCE(te.name,'?') AS teacher_name,
                  t.room_id, COALESCE(r.name,'?') AS room_name
           FROM timetable t
           LEFT JOIN classes c ON c.id = t.class_id
           LEFT JOIN teachers te ON te.id = t.teacher_id
           LEFT JOIN rooms r ON r.id = t.room_id
           ORDER BY t.class_id, t.day, t.slot"""
    )
