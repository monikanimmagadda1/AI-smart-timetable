# 🗓️ AI Smart Timetable & Alert System

A simple Streamlit app that generates a conflict-free school/college timetable with
Google OR-Tools, lets you edit it with an instant conflict preview, and sends change
alerts and class reminders (in-app, email, mock SMS).

## Setup
```bash
python -m venv venv
source venv/bin/activate          # Windows: venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env              # optional: only needed for real email
streamlit run app.py
```
Sample teachers, classes, rooms and subjects load automatically on first run.

## Demo walkthrough (2 minutes)
1. **Admin → ⚙️ Generate** → *Generate timetable* (creates ~75 sessions, no clashes).
2. **Admin → 📅 Timetable** → switch between Class / Teacher / Room views (colour-coded by subject).
3. Scroll to **Edit**: pick a session, choose a new day/period. You get a live preview; a clash
   (teacher, room, class, unavailable teacher, small room) blocks saving. If the target period is
   occupied by another session of the same class, the two sessions swap.
4. Save with "Send alerts" ticked → **Delivery Log** shows in-app / email / SMS rows.
5. **Admin → 📣 Post Change** → room change, time shift, cancellation, exam reschedule.
6. Switch role to **Teacher** or **Student** (sidebar): see your own timetable, toast alerts
   (polled every 15 s), and **⏰ Reminders** to set lead time (10/15/30/45/60 or custom)
   and press **Test reminder now**.

## How it works
| File | Purpose |
|---|---|
| `app.py` | Streamlit UI, role switch, all pages |
| `db.py` | SQLite tables + helpers |
| `scheduler_engine.py` | OR-Tools CP-SAT model (hard + soft constraints), pre-checks that explain infeasibility, greedy fallback if OR-Tools is missing |
| `ops.py` | Move/swap, room change, cancel, exam reschedule + alert dispatch |
| `notifier.py` | In-app, SMTP email, mock SMS (Twilio example in comments) |
| `reminders.py` | APScheduler job (every minute), per-user lead time, no duplicate reminders |
| `utils.py` | Colour-coded HTML grid, conflict checker, settings parsing |
| `seed_data.py` | Demo data (`python seed_data.py --force` to reset) |

**Hard constraints:** no teacher/class/room double-booking, room capacity ≥ class size, exact weekly hours
per subject, teacher unavailability. **Soft:** spread a subject across days, avoid 3 periods in a row.

## Email / SMS
- Email: fill `.env` (Gmail needs an App Password). Without it, email rows show "skipped" in the Delivery Log.
- SMS is a console mock in `notifier.send_sms_mock`; swap in Twilio there.
- Students have no login: alerts go to the class's group email (Data → Classes → email).

## Notes / limits
- Reminders fire only while the Streamlit process is running.
- Cancellation removes the weekly session (no one-off exceptions).
- Drag-and-drop is replaced by dropdown move/swap with live preview (simple and reliable in Streamlit);
  `streamlit-sortables` can be added later.
- Push notifications: toasts + unread badge in-app; for phone push, ntfy.sh can be added in `notifier.py`.
