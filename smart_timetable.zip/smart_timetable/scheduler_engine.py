"""Timetable generation.

Main engine: Google OR-Tools CP-SAT (constraint programming + optimisation).
Fallback (only if ortools is not installed): a simple randomised greedy solver,
so the app still runs. Both honour the same hard constraints.

HARD constraints
  * a teacher teaches at most one class per period
  * a class has at most one subject per period
  * a room hosts at most one class per period, and capacity >= class size
  * every subject gets exactly its weekly hours per class
  * teachers are never scheduled in their unavailable periods
SOFT constraints (minimised)
  * the same subject twice on one day for a class
  * 3 consecutive periods of the same subject
"""
import random

import db
import utils

try:
    from ortools.sat.python import cp_model
    HAVE_ORTOOLS = True
except ImportError:  # pragma: no cover
    HAVE_ORTOOLS = False


def _load():
    teachers = db.query("SELECT * FROM teachers")
    classes = db.query("SELECT * FROM classes")
    rooms = db.query("SELECT * FROM rooms")
    subjects = db.query("SELECT * FROM subjects")
    days = utils.get_days()
    n = len(utils.get_slot_times())
    unavail = {int(r.id): utils.parse_unavailable(r.unavailable) for r in teachers.itertuples()}
    return teachers, classes, rooms, subjects, days, n, unavail


def precheck(teachers, classes, rooms, subjects, days, n, unavail):
    """Cheap sanity checks that explain the most common reasons for infeasibility."""
    problems = []
    if subjects.empty or classes.empty or rooms.empty or teachers.empty:
        return ["Add at least one teacher, class, room and subject first."]
    total_slots = len(days) * n
    tid_set, cid_set = set(teachers.id), set(classes.id)
    size = dict(zip(classes.id, classes["size"]))
    cname, tname = dict(zip(classes.id, classes.name)), dict(zip(teachers.id, teachers.name))
    max_cap = rooms.capacity.max()
    for s in subjects.itertuples():
        if s.class_id not in cid_set or s.teacher_id not in tid_set:
            problems.append(f"Subject '{s.name}' has a missing class or teacher.")
    for cid, g in subjects.groupby("class_id"):
        if cid in cid_set and g.hours.sum() > total_slots:
            problems.append(f"Class {cname[cid]} needs {g.hours.sum()} periods/week but only {total_slots} exist.")
        if cid in cid_set and size[cid] > max_cap:
            problems.append(f"No room is big enough for class {cname[cid]} ({size[cid]} students, largest room {max_cap}).")
    for tid, g in subjects.groupby("teacher_id"):
        if tid in tid_set:
            free = total_slots - len(unavail.get(tid, set()))
            if g.hours.sum() > free:
                problems.append(f"Teacher {tname[tid]} must teach {g.hours.sum()} periods but is only available for {free}.")
    if subjects.hours.sum() > total_slots * len(rooms):
        problems.append("Total teaching hours exceed the total room capacity (periods x rooms).")
    return problems


def _save(rows):
    with db.conn() as c:
        c.execute("DELETE FROM timetable")
        c.executemany(
            "INSERT INTO timetable(class_id, day, slot, subject, teacher_id, room_id) VALUES(?,?,?,?,?,?)", rows)


def _solve_cpsat(classes, rooms, subjects, days, n, unavail, time_limit):
    size = dict(zip(classes.id, classes["size"]))
    model = cp_model.CpModel()
    x = {}
    by_sub, by_class, by_teacher, by_room = {}, {}, {}, {}
    for s in subjects.itertuples():
        for d in days:
            for p in range(1, n + 1):
                if (d, p) in unavail.get(int(s.teacher_id), set()):
                    continue
                for r in rooms.itertuples():
                    if r.capacity < size[s.class_id]:
                        continue
                    v = model.NewBoolVar(f"x{s.id}_{d}_{p}_{r.id}")
                    x[(s.id, d, p, r.id)] = v
                    by_sub.setdefault(s.id, []).append(v)
                    by_class.setdefault((s.class_id, d, p), []).append(v)
                    by_teacher.setdefault((s.teacher_id, d, p), []).append(v)
                    by_room.setdefault((r.id, d, p), []).append(v)
    for s in subjects.itertuples():
        model.Add(sum(by_sub.get(s.id, [])) == int(s.hours))
    for group in (by_class, by_teacher, by_room):
        for vs in group.values():
            model.AddAtMostOne(vs)

    penalties = []
    for s in subjects.itertuples():
        y = {}
        for d in days:
            for p in range(1, n + 1):
                vs = [x[k] for k in ((s.id, d, p, r.id) for r in rooms.itertuples()) if k in x]
                y[(d, p)] = model.NewBoolVar(f"y{s.id}_{d}_{p}")
                model.Add(y[(d, p)] == sum(vs))
        for d in days:
            excess = model.NewIntVar(0, n, f"ex{s.id}_{d}")
            model.Add(excess >= sum(y[(d, p)] for p in range(1, n + 1)) - 1)
            penalties.append(excess)
            for p in range(1, n - 1):
                t = model.NewBoolVar(f"t{s.id}_{d}_{p}")
                model.Add(y[(d, p)] + y[(d, p + 1)] + y[(d, p + 2)] <= 2 + t)
                penalties.append(3 * t)
    model.Minimize(sum(penalties))

    solver = cp_model.CpSolver()
    solver.parameters.max_time_in_seconds = float(time_limit)
    solver.parameters.num_workers = 4
    status = solver.Solve(model)
    name = solver.StatusName(status)
    if status not in (cp_model.OPTIMAL, cp_model.FEASIBLE):
        return None, name
    sub_info = {s.id: s for s in subjects.itertuples()}
    rows = [(int(sub_info[sid].class_id), d, p, sub_info[sid].name, int(sub_info[sid].teacher_id), int(rid))
            for (sid, d, p, rid), v in x.items() if solver.Value(v)]
    return rows, name


def _solve_greedy(classes, rooms, subjects, days, n, unavail, time_limit, tries=300):
    """Fallback: place one period at a time in random order; retry on dead ends."""
    size = dict(zip(classes.id, classes["size"]))
    units = [s for s in subjects.itertuples() for _ in range(int(s.hours))]
    for _ in range(tries):
        random.shuffle(units)
        units.sort(key=lambda s: -s.hours)
        used_c, used_t, used_r, rows = set(), set(), set(), []
        per_day = {}
        ok = True
        for s in units:
            slots = [(d, p) for d in days for p in range(1, n + 1)]
            random.shuffle(slots)
            slots.sort(key=lambda dp: per_day.get((s.id, dp[0]), 0))  # prefer spreading over days
            placed = False
            for d, p in slots:
                if (d, p) in unavail.get(int(s.teacher_id), set()):
                    continue
                if (s.class_id, d, p) in used_c or (s.teacher_id, d, p) in used_t:
                    continue
                for r in rooms.itertuples():
                    if r.capacity >= size[s.class_id] and (r.id, d, p) not in used_r:
                        used_c.add((s.class_id, d, p)); used_t.add((s.teacher_id, d, p)); used_r.add((r.id, d, p))
                        per_day[(s.id, d)] = per_day.get((s.id, d), 0) + 1
                        rows.append((int(s.class_id), d, p, s.name, int(s.teacher_id), int(r.id)))
                        placed = True
                        break
                if placed:
                    break
            if not placed:
                ok = False
                break
        if ok:
            return rows, "FEASIBLE (greedy fallback)"
    return None, "INFEASIBLE"


def generate(time_limit=20):
    """Generate and save a timetable. Returns {'ok', 'status', 'rows', 'messages'}."""
    teachers, classes, rooms, subjects, days, n, unavail = _load()
    problems = precheck(teachers, classes, rooms, subjects, days, n, unavail)
    if problems:
        return {"ok": False, "status": "PRECHECK_FAILED", "rows": 0, "messages": problems}
    solver = _solve_cpsat if HAVE_ORTOOLS else _solve_greedy
    rows, status = solver(classes, rooms, subjects, days, n, unavail, time_limit)
    if rows is None:
        hint = ("Timed out before finding a schedule - raise the time limit." if status == "UNKNOWN" else
                "No schedule satisfies all hard constraints. Likely causes: too many periods for a teacher "
                "on too few available slots, too few rooms big enough for a class, or too many hours per class. "
                "Try adding rooms, reducing hours, or freeing up teacher availability.")
        return {"ok": False, "status": status, "rows": 0, "messages": [hint]}
    _save(rows)
    msgs = [] if HAVE_ORTOOLS else ["OR-Tools not installed - used the simple greedy fallback. Run `pip install ortools` for optimised results."]
    return {"ok": True, "status": status, "rows": len(rows), "messages": msgs}
